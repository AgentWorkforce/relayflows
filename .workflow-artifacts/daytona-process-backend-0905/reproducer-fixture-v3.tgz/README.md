# Daytona deterministic-step reproducer fixture (relayflows#52)

This tiny git repo is the "source root" a relayflow runs against under
`RELAYFLOWS_SANDBOX_PROVIDER=daytona`. The committed tree at HEAD is the exact
source every deterministic step must see synced inside the sandbox, and the
HEAD commit + tree digest are the binding every step must receive.

- `reproducer.yaml` — the two-step reproducer workflow. Step 1 asserts the
  synced source is present (`reproducer-marker.txt`), records the sandbox id
  it was given, and prints the id/commit/digest bindings. Step 2 asserts it
  landed in the SAME sandbox (reads back the id file) with the SAME bindings.
- `reproducer-marker.txt` — the file whose presence proves source sync.
